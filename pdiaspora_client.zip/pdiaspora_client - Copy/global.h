#ifdef A_H_
  #define EXTERN
#else
  #define EXTERN extern
#endif

EXTERN MyClass inst;
